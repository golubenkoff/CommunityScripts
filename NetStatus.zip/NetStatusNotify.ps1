﻿#region Config

# Load assembly
[System.Reflection.Assembly]::LoadWithPartialName("System.Windows.Forms")

$Global:Text = @"
УВАГА!

Зараз з технічних причин у вас відсутнє інтернет-з'єднання. 

Спробуйте перевантажити 3g-модем, роутер або інше наявне інтернет-обладнання. 

Якщо інтернет не з'явився через 5-10 хвилин, зверніться до свого системного адміністратора!

"@
#endregion Config

function GLOBAL:CheckConnection {
param(
[string]$ComputerName="1.1.1.1",
[int]$timeout=1000
)
$TestResult = $null
$ping = [System.Net.NetworkInformation.Ping]::new()
$TestResult = $ping.Send($ComputerName, $timeout)
if ($TestResult.status -eq "Success"){return 0}
else{return 1}
}

function GLOBAL:ShowNotification {
param(
[string]$Text
)

if (GLOBAL:CheckConnection -ne 0)
{
get-job | stop-job
get-job | Remove-Job
$oReturn=[System.Windows.Forms.Messagebox]::Show($Text,"Відсутнє інтернет з'єднання",[System.Windows.Forms.MessageBoxButtons]::OK,[System.Windows.Forms.MessageBoxIcon]::Warning)
GLOBAL:RegisterMonitor
[System.GC]::Collect() 
}else{
[System.GC]::Collect()
}
}


function GLOBAL:RegisterMonitor{
$timer = New-Object System.Timers.Timer
$timer.Enabled = $true
$timer.Interval = 600000
$timer.AutoReset = $true

$MessageData = "" | Select Text
$MessageData.Text = $Text
Register-ObjectEvent -InputObject $timer -EventName Elapsed -MessageData $MessageData -Action { GLOBAL:ShowNotification -Text $Event.MessageData.Text } | Out-Null
}
#---------------------------------------------------------------------------------------------------------
GLOBAL:RegisterMonitor
#---------------------------------------------------------------------------------------------------------
do{}while($true)
#---------------------------------------------------------------------------------------------------------
